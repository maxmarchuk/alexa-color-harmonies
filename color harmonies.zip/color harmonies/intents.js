{
  "intents": [
    {
      "name": "AMAZON.CancelIntent",
      "samples": []
    },
    {
      "name": "AMAZON.HelpIntent",
      "samples": []
    },
    {
      "name": "AMAZON.StopIntent",
      "samples": []
    },
    {
      "name": "getColorsIntent",
      "samples": [
        "What are the {harmonyType} colors",
        "What is the {harmonyType} color"
      ],
      "slots": [
        {
          "name": "harmonyType",
          "type": "COLOR_HARMONIES",
          "samples": []
        }
      ]
    },
    {
      "name": "setColorIntent",
      "samples": [
        "set color to {first} {second} {third}",
        "set color to {first} {second} {third} {fourth} {fifth} {sixth}"
      ],
      "slots": [
        {
          "name": "first",
          "type": "HEXADECIMAL_VALUES",
          "samples": []
        },
        {
          "name": "second",
          "type": "HEXADECIMAL_VALUES",
          "samples": []
        },
        {
          "name": "third",
          "type": "HEXADECIMAL_VALUES",
          "samples": []
        },
        {
          "name": "fourth",
          "type": "HEXADECIMAL_VALUES",
          "samples": []
        },
        {
          "name": "fifth",
          "type": "HEXADECIMAL_VALUES",
          "samples": []
        },
        {
          "name": "sixth",
          "type": "HEXADECIMAL_VALUES",
          "samples": []
        }
      ]
    }
  ],
  "types": [
    {
      "name": "COLOR_HARMONIES",
      "values": [
        {
          "id": null,
          "name": {
            "value": "complementary",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "split complementary",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "triadic",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "tetradic",
            "synonyms": []
          }
        }
      ]
    },
    {
      "name": "HEXADECIMAL_VALUES",
      "values": [
        {
          "id": null,
          "name": {
            "value": "A",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "B",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "C",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "D",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "E",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "F",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "1",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "2",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "3",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "4",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "5",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "6",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "7",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "8",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "9",
            "synonyms": []
          }
        },
        {
          "id": null,
          "name": {
            "value": "0",
            "synonyms": []
          }
        }
      ]
    }
  ]
}