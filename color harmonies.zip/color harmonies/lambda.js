'use strict';

// --------------- Helpers that build all of the responses -----------------------

function buildColorSetResponse(speechOutput, hexColor) {
    const cardTitle = 'Color Harmonies - Set Color';
    
    
    return {
        outputSpeech: {
          type: "PlainText",
          text: speechOutput,
        },
        card: {
            type: 'Simple',
            title: `Color Harmonies - Color set to #${hexColor}.`,
            content: `Set the session's color to  #${hexColor}.`,
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: 'You may now request harmonies for this color.'
            }
        },
        shouldEndSession: false
    };
}

function buildInvalidColorResponse() {
    return {
        outputSpeech: {
          type: "PlainText",
          text: 'Invalid color. Please set a color for this session by saying "set color to f, f, f".',
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: 'Set a color for this session by saying "set color to f, f, f".'
            }
        },
        shouldEndSession: false
    };
}

function buildHelpResponse() {
    const prompText = '';
    const welcomeText = 'To set a color to work with, you can say, set color to ' + 
        'f, f, zero. You can use any hexadecimal color as long as it is ' + 
        '3 or 6 characters. ' + 
        'If you want to get a color harmony for your colors, simple say ' + 
        'the name of the harmony, followed by the word "colors". for now, you ' + 
        'can only find the comlementary color so you can can just say, ' + 
        'complementary colors.';
        
        
    return {
        outputSpeech: {
            type: 'PlainText', 
            text: welcomeText
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: prompText
            }
        },
        shouldEndSession: false
    }
}
function buildNoColorSetResponse() {
    return {
        outputSpeech: {
            type: 'PlainText',
            text: 'A valid color has not been set yet. Please set a color by saying '   
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: 'Please try again.',
            }
        },
        shouldEndSession: false
    }
}

function buildInvalidHarmonyTypeResponse() {
    return {
        outputSpeech: {
            type: 'PlainText',
            text: "I'm sorry, that is not a supported harmony. Please try again."   
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: 'Please try again.',
            }
        },
        shouldEndSession: false
    }
}

function buildComplementaryResponse(spokenComplement, hexColor, hexComplementaryColor) {
    const repromptText = `You may now ask for another color harmony, set a new color, or cancel the session by saying stop`;
    const ssml = `<speak> The complementary color is: ${spokenComplement}. ${repromptText}.</speak>`;
    return {
        outputSpeech: {
            type: 'SSML',
            ssml: `${ssml}`
        },
        card: {
            type: 'Simple',
            title: `Complementary harmony for #${hexColor}`,
            content: `The complementary color for #${hexColor} is #${hexComplementaryColor}.`,
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: repromptText
            },
        },
        shouldEndSession: false,
    };
}

function getHexFromSession(session) {
    const { first, second, third, fourth, fifth, sixth } = session.attributes;
    let hex = '';
    hex += first.value + second.value + third.value;
    if (fourth && fourth.value && fifth && fifth.value && sixth && sixth.value) {
        hex += fourth.value + fifth.value + sixth.value;
    }
    console.log('hex is ', hex, ' and length is ', hex.length);
    if(hex.length === 3) {
        console.log('hex before: ', hex)
        hex = hex + hex;
        console.log('hex after: ', hex)
    }
    
    return hex;
}

function getComplement(hex) {
    var hsb = hexToHsb(hex);
    hsb.h = getComp(hsb.h);
    
    const compHex = hsbToHex(hsb);
    return compHex;
}


function buildResponse(sessionAttributes, speechletResponse) {
    return {
        version: '1.0',
        sessionAttributes,
        response: speechletResponse,
    };
}


// --------------- Functions that control the skill's behavior -----------------------

function getWelcomeResponse(callback) {
    const promptText = 'Tell me your current color by saying, My color is f f f';
    const welcomeText = 'Welcome to the Color Harmony Skill. ' + promptText;
        
    const sessionStartResponse = {
        outputSpeech: {
            type: 'PlainText', 
            text: welcomeText
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: promptText
            }
        },
        shouldEndSession: false
    }
    
    callback({}, sessionStartResponse);
}

function getHelpResponse(callback) {
    callback({}, buildHelpResponse())
}

function handleSessionEndRequest(callback) {
    const sessionEndResponse = {
        outputSpeech: {
            type: 'PlainText', 
            text: 'Goodbye'
        },
        shouldEndSession: true
    };
    
    callback({}, sessionEndResponse);
}

function createCurrentColorAttributes(currentColor) {
    return {
        currentColor,
    };
}

/**
 * Sets the color in the session and prepares the speech to reply to the user.
 */
function setColorInSession(intent, session, callback) {
    const colorSlot = intent.slots.Color;
    let repromptText = 'Please ask for a color harmony now.';
    let sessionAttributes = {};
    let shouldEndSession = false;
    let speechOutput = '';
    
    const { first, second, third, fourth, fifth, sixth } = intent.slots;
    
    if((first && first.value) && (second && second.value) && (third && third.value)) {
        speechOutput = 'Your color has been set to: '
        speechOutput += `${first.value}, ${second.value}, ${third.value}`;
    } else { // if the first three hex values are invalid or have not been set
        // tell the user their input is invalid and reprompt
        callback(sessionAttributes, buildInvalidColorResponse());
    }
    
    // if the user decided to set a hex color with 6 characters/numbers
    if((fourth && fourth.value) && (fifth && fifth.value) && (sixth && sixth.value)) {
        speechOutput += `${fourth.value}, ${fifth.value}, ${sixth.value}.`;
    } else {
        speechOutput +="."
    }
    
    sessionAttributes = {
        first, second, third, fourth, fifth, sixth
    };
   
   const hexColor = getHexFromSession( { attributes: sessionAttributes } );
   speechOutput = ' You can now request a harmony by saying, "What is the complementary color"?';
   
    callback(sessionAttributes, buildColorSetResponse(speechOutput, hexColor));
}
function sessionHasColorSet(session) {
    let hex = '';
    const { first, second, third, fourth, fifth, sixth } = session.attributes;
    if(first && first.value && second && second.value && third && third.value) {
        hex += first.value + second.value + third.value;    
    }
    
    if (fourth && fourth.value && fifth && fifth.value && sixth && sixth.value) {
        hex += fourth.value + fifth.value + sixth.value;
    }
    
    return hex.length > 0;
}

function getColorsForSession(intent, session, callback) {
    let repromptText = null;
    let shouldEndSession = false;
    let speechOutput = '';
    let responseObject = null;
    const colorIsNotSet = !sessionHasColorSet(session);
    const harmonyType = intent.slots.harmonyType.value;
    
    if(colorIsNotSet) {
        callback(session.attributes, buildInvalidColorResponse());
    }
    if(harmonyType && harmonyType === 'complementary') {
        const hex = getHexFromSession(session);
        const compHex = getComplement(hex);
        const spokenComplement = buildSpeakableColor(compHex);
        
        responseObject = buildComplementaryResponse(spokenComplement, hex, compHex);
    } else {
        responseObject = buildInvalidHarmonyTypeResponse();
    }
    
    
    callback(session.attributes, responseObject);
}
function getCurrentColor(intent, session, callback) {
    const repromptText = null;
    const sessionAttributes = {};
    
}

// --------------- Events -----------------------

/**
 * Called when the session starts.
 */
function onSessionStarted(sessionStartedRequest, session) {
    console.log(`onSessionStarted requestId=${sessionStartedRequest.requestId}, sessionId=${session.sessionId}`);
}

/**
 * Called when the user launches the skill without specifying what they want.
 */
function onLaunch(launchRequest, session, callback) {
    console.log(`onLaunch requestId=${launchRequest.requestId}, sessionId=${session.sessionId}`);

    // Dispatch to your skill's launch.
    getWelcomeResponse(callback);
}

/**
 * Called when the user specifies an intent for this skill.
 */
function onIntent(intentRequest, session, callback) {
    console.log(`onIntent requestId=${intentRequest.requestId}, sessionId=${session.sessionId}`);

    const intent = intentRequest.intent;
    const intentName = intentRequest.intent.name;

    // Dispatch to your skill's intent handlers
    if (intentName === 'setColorIntent') {
        setColorInSession(intent, session, callback);
    } else if (intentName === 'getColorsIntent') {
        getColorsForSession(intent, session, callback);
    } else if (intentName === 'getCurrentColorIntent') {
        getCurrentColor(intent, session, callback);
    }
    else if (intentName === 'AMAZON.HelpIntent') {
        getHelpResponse(callback);
    } else if (intentName === 'AMAZON.StopIntent' || intentName === 'AMAZON.CancelIntent') {
        handleSessionEndRequest(callback);
    } else {
        throw new Error('Invalid intent');
    }
}

/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session) {
    console.log(`onSessionEnded requestId=${sessionEndedRequest.requestId}, sessionId=${session.sessionId}`);
    // Add cleanup logic here
}


// --------------- Main handler -----------------------

// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.
exports.handler = (event, context, callback) => {
    try {
        console.log(`event.session.application.applicationId=${event.session.application.applicationId}`);

        /**
         * Uncomment this if statement and populate with your skill's application ID to
         * prevent someone else from configuring a skill that sends requests to this function.
         */
        /*
        if (event.session.application.applicationId !== 'amzn1.echo-sdk-ams.app.[unique-value-here]') {
             callback('Invalid Application ID');
        }
        */

        if (event.session.new) {
            onSessionStarted({ requestId: event.request.requestId }, event.session);
        }

        if (event.request.type === 'LaunchRequest') {
            onLaunch(event.request,
                event.session,
                (sessionAttributes, speechletResponse) => {
                    callback(null, buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === 'IntentRequest') {
            onIntent(event.request,
                event.session,
                (sessionAttributes, speechletResponse) => {
                    callback(null, buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === 'SessionEndedRequest') {
            onSessionEnded(event.request, event.session);
            callback();
        }
    } catch (err) {
        callback(err);
    }
};


function hexToRgb(hex) {
    var hex = parseInt(((hex.indexOf('#') > -1) ? hex.substring(1) : hex), 16);
    return {r: hex >> 16, g: (hex & 0x00FF00) >> 8, b: (hex & 0x0000FF)};
}

function hexToHsb(hex) {
    return rgbToHsb(hexToRgb(hex));
}

function rgbToHsb(rgb) {
    var hsb = {h: 0, s: 0, b: 0};
    var min = Math.min(rgb.r, rgb.g, rgb.b);
    var max = Math.max(rgb.r, rgb.g, rgb.b);
    var delta = max - min;
    hsb.b = max;
    hsb.s = max !== 0 ? 255 * delta / max : 0;
    if (hsb.s !== 0) {
        if (rgb.r == max) hsb.h = (rgb.g - rgb.b) / delta;
        else if (rgb.g == max) hsb.h = 2 + (rgb.b - rgb.r) / delta;
        else hsb.h = 4 + (rgb.r - rgb.g) / delta;
    } else hsb.h = -1;
    hsb.h *= 60;
    if (hsb.h < 0) hsb.h += 360;
    hsb.s *= 100 / 255;
    hsb.b *= 100 / 255;
    return hsb;
}

function hsbToRgb(hsb) {
    var rgb = {};
    var h = Math.round(hsb.h);
    var s = Math.round(hsb.s * 255 / 100);
    var v = Math.round(hsb.b * 255 / 100);
    if (s === 0) {
        rgb.r = rgb.g = rgb.b = v;
    } else {
        var t1 = v;
        var t2 = (255 - s) * v / 255;
        var t3 = (t1 - t2) * (h % 60) / 60;
        if (h == 360) h = 0;
        if (h < 60) {
            rgb.r = t1;
            rgb.b = t2;
            rgb.g = t2 + t3
        }
        else if (h < 120) {
            rgb.g = t1;
            rgb.b = t2;
            rgb.r = t1 - t3
        }
        else if (h < 180) {
            rgb.g = t1;
            rgb.r = t2;
            rgb.b = t2 + t3
        }
        else if (h < 240) {
            rgb.b = t1;
            rgb.r = t2;
            rgb.g = t1 - t3
        }
        else if (h < 300) {
            rgb.b = t1;
            rgb.g = t2;
            rgb.r = t2 + t3
        }
        else if (h < 360) {
            rgb.r = t1;
            rgb.g = t2;
            rgb.b = t1 - t3
        }
        else {r
            rgb.r = 0;
            rgb.g = 0;
            rgb.b = 0
        }
    }
    return {r: Math.round(rgb.r), g: Math.round(rgb.g), b: Math.round(rgb.b)};
}

function rgbToHex(rgb) {
    var hex = [
        rgb.r.toString(16),
        rgb.g.toString(16),
        rgb.b.toString(16)
    ];

    for (var i=0; i<=hex.length-1; i++) {
        if(hex[i].length === 1) {
            hex[i] = '0' + hex[i]
        }
    }
    return hex.join('');
}

function hsbToHex(hsb) {
    return rgbToHex(hsbToRgb(hsb));
}

function getComp(h){
	return polarize(h + 180);
}

function polarize(h){
	if(h > 360) h = h - 360;
	if(h < 0) h = h + 360;
	return h;
}


function buildSpeakableColor(hex) {
    if(hex) {
        if(hex.length === 6) {
            // Try to cut the hex in half if it would still be valid
            if(hex.slice(0, 3) == hex.slice(3, 6)) {
                hex = hex.slice(0,3);
            }
        }
    }
    //build the speakable ssml, and tell alexa to interpret the hex numbers as 
    // individual characters and numbers, based on their type
    
    var ssml = '';
    var speechType;
    
    hex.split('').forEach((a) => {
        speechType = 'characters';
        
        if(!isNaN(parseInt(a))) {
        	speechType = 'digits';
        }
        
        ssml += '<say-as interpret-as="' + speechType + '">' + a + '</say-as> ';
    });

    return ssml;
}
